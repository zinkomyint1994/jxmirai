<!-- <?php
function my_theme_enqueue_styles() {
    wp_enqueue_style('normalize', get_template_directory_uri() . '/assets/css/normalize.css');

    wp_enqueue_style('theme-style', get_stylesheet_uri() . '/assets/css/style.css'); // Your main style.css

    wp_enqueue_style('main-style', get_template_directory_uri() . '/assets/css/main.css');
}
add_action('wp_enqueue_scripts', 'my_theme_enqueue_styles');

function my_theme_register_menus() {
    register_nav_menus(array(
        'main-menu' => __('Main Menu', 'my-custom-theme'),
    ));
}
add_action('init', 'my_theme_register_menus');

add_action('wp_enqueue_scripts', 'my_theme_enqueue_styles');


?> -->
