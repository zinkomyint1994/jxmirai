<?php
$globalFont = 'Arial, sans-serif';
?>
<style>
    :root {
        --global-font: <?php echo $globalFont; ?>;
    }
</style>
