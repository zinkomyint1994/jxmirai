<!DOCTYPE html>
<html lang="en">
<body>
    <div class="blue_line_wrap">
    </div>
</body>
</html>
