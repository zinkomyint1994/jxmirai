<!DOCTYPE html>
<html lang="en">
<body>
    <div class="subtitle-wrapper">
        <div class="sub-blue"></div>
        <div class="subtitle-txt ">  <?php
                global $title;
                echo $title;
                ?></div>
          
    </div>
</body>
</html>
