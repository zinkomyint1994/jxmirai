<!DOCTYPE html>
<html lang="en">
<head>
    <title>jxmirai</title>
</head>
<body>
    <div class="main-banner-wrapper">
        <div class="banner-overlayq">
           <div class="banner-img-container">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/banner/banner.png" alt="Example Image" class="responsive_image_main">
            </div>
           
        </div> 
        <div class="main-title-wrapper">
            <div class="main-inner-wrap">
                <div><h2>JX 未来株式会社</h2></div>
                <div><h1>FUTURE CORPORATION</h1></div>
                <div class="banner-description"> JX Mirai とのコラボレーションは、品質と顧客満足への取り組みを基盤として、 革新性、精度、コスト効率を融合した企業と提携することを意味します。</div>
                <div class="banner-btn-wrapper">
        <!-- <?php
            include get_template_directory() . '/custom/buttontype1.php';
            ?> -->
        </div>
        </div>
            </div>
       
    </div>
</body>
</html>
