<!DOCTYPE html>
<html lang="en">
<head>
    <title>Include Example</title>
</head>
<body>
    <div class="main-banner-wrapper">
        <div>
        <div class="banner-img-container">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/banner/banner.png" alt="Example Image" class="responsive-image">
        </div>
      
        </div>
    </div>
</body>
</html>
