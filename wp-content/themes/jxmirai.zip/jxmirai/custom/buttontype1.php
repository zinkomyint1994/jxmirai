<!DOCTYPE html>
<html lang="en">
<body>
    <div class="arrow-btn-wrapper">
        <p>もっと読む</p>
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/banner/arrow.png" alt="Example Image" class="arrow-png">
    </div>
</body>
</html>
